# Copyright (c) 2023 - 2024 Jakub Więckowski

dir_path = './'
# TODO change value for actual TIMEOUT - 300 sec
REQUEST_TIMEOUT = 5 # in seconds
