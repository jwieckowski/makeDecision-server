from .correlations import correlation_methods
from .mcda import mcda_methods
from .weights import weights_methods