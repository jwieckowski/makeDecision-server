# Copyright (c) 2023 - 2024 Jakub Więckowski

dir_path = './'
REQUEST_TIMEOUT = 300 # in seconds
